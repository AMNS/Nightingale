/* DynamicEdit.h for Nightingale */

Boolean SetDynamicDialog(SignedByte *dynamicType);
